package StepDefinitions;

import io.cucumber.java.*;
import io.cucumber.java.en.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.openqa.selenium.*;

public class product {
	String baseUrl="https://www.amazon.in/";
	public static WebDriver driver=new ChromeDriver();
	@BeforeClass
	public void browser_setup() {
		System.out.println("Browser setup");
//		public static WebDriver driver=new ChromeDriver();
		driver=new ChromeDriver();
		System.setProperty("webdriver.chrome.driver","C:/Users/91979/eclipse-workspace/CucumberjAVA/src/test/resources/driver/chrome.exe");
		
	}
	@AfterClass
	public void browser_close() throws InterruptedException {
		Thread.sleep(5000);
		driver.quit();
		System.out.println("Closed the browser");
	}
	@Given("I was in amazon home page")
	public void home_page() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Home Page ");
	    System.out.println("Base url is "+baseUrl);
		driver.navigate().to(baseUrl);
	}
	@Given("^I enter the login details (.*)$")
	public void login_details(String arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Mobile -"+arg1);
	    WebElement signin_hover=driver.findElement(By.xpath("//span[text()='Hello, sign in']"));
	    Actions hover=new Actions(driver);
	    hover.moveToElement(signin_hover);
	    driver.switchTo().parentFrame();
	    WebElement Signin=driver.findElement(By.xpath("(//span[text()='Sign in']/parent::a[@href])[1]"));
	    String href=Signin.getAttribute("href");
	    System.out.println("Href is "+href);
	    driver.get(href);
	    WebElement mob=driver.findElement(By.xpath("(//label[contains(text(),'Email or mobile phone number')]/following::input)[1]"));
	    mob.sendKeys(arg1);
	    driver.findElement(By.xpath("//input[@id='continue']")).click();
	    System.out.println("Clicked login");
	    String msg=driver.findElement(By.xpath("(//h4[@class='a-alert-heading'])[1]")).getText();
	    System.out.println("Alert msg "+msg);
	    if(!msg.equals(null)) {
	    	throw new Exception("Invalid login "+msg);
	    }

	}
	@Then("^I enter the password (.*)$")
	public void password_detail(String arg1) throws IllegalAccessException{
		System.out.println("Password -"+arg1);
	    if(driver.findElement(By.xpath("//label[contains(text(),'Password')]")).isDisplayed()) {
	    	System.out.println("Entering password "+arg1);
	    	WebElement password=driver.findElement(By.xpath("(//label[contains(text(),'Password')]/following::input)[1]"));
	    	password.sendKeys(arg1);
	    	driver.findElement(By.xpath("//input[@id='signInSubmit']")).click();
	    	System.out.println("Sign in clicked");
	    	WebElement validate_account=driver.findElement(By.xpath("//span[@id='nav-link-accountList-nav-line-1']"));
	    	String acc_name=validate_account.getText();
	    	System.out.println("Account name is "+acc_name);
	    	Boolean res_acc=acc_name.contains("Hello");
	    	if(res_acc==true) {
	    		System.out.println("Logged in succesfully ");
	    	}
	    	else {
	    		System.out.println("Not Logged in succesfully ");
	    		throw new IllegalAccessException("Not logged in");
	    	}
	    }

	    
	}

	@When("I check for the {int} in step")
	public void i_check_for_the_in_step(Integer int1) {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Data 2-"+int1);
	}

	@Given("^I search the (.*)$")
	public void search_product(String product) {
		WebElement search=driver.findElement(By.xpath("//input[@placeholder='Search Amazon.in']"));
	    System.out.println("Product name -"+product);
	    search.sendKeys(product);
	    search.sendKeys(Keys.ENTER);
	    System.out.println("Pressed enter");
	    }
	@Then("^I verify the page of (.*)$")
	public void verify_product(String product) {
		WebElement product_page=driver.findElement(By.xpath("//span[@class='a-size-medium a-color-base a-text-normal']"));
		String searched_pro=product_page.getText();
	    System.out.println("Product name is "+searched_pro);
	    Boolean res=searched_pro.contains(product);
	    System.out.println("Result  "+res);
	    Assert.assertEquals(res,true);
	    
	    
	    }
	@Then("^I add the product to cart$")
	public void add_to_cart () {
		System.out.println("Switched-");
		String parent=driver.getWindowHandle();
		System.out.println("Parent window "+parent);
		WebElement product_page=driver.findElement(By.xpath("//span[@class='a-size-medium a-color-base a-text-normal']"));
		product_page.click();
		driver.navigate().refresh();
		Set <String> handles=driver.getWindowHandles();
		System.out.println("Handles "+handles);
		String product_title="";
		String product_window="";
		for(String win:handles) {
			if(!win.equals(parent)) {
				driver.switchTo().window(win);
				product_title=driver.getTitle();
				product_window=driver.getWindowHandle();
				System.out.println("title is "+driver.getTitle());
				break;	
			} 
		}
		driver.switchTo().window(product_window);
		driver.navigate().refresh();
		WebElement add_cart=driver.findElement(By.xpath("(//input[@id='add-to-cart-button'])[last()]"));
		add_cart.click();
		
	    }
	@Then("^I proceed to checkout for (.*)$")
	public void checkout(String product) {
		System.out.println("Checkout function for "+product);
		driver.navigate().refresh();
		driver.findElement(By.xpath("//span[@id='nav-cart-count']")).click();
		String product_validation="//span[contains(text(),'"+product+"')]";
		WebElement check_product=driver.findElement(By.xpath(product_validation));
		String result_product=check_product.getText();
		Boolean result=result_product.contains(product);
	    System.out.println("Result  "+result);
		WebElement checkout=driver.findElement(By.xpath("//input[@value='Proceed to checkout']"));
		checkout.click();
		
	}

}
