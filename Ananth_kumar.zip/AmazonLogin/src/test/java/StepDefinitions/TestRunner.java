package StepDefinitions;

import org.junit.runner.RunWith;

import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/resources/Features",glue= {"StepDefinitions"},monochrome=true,

plugin={"pretty","junit:target/Reports/report.xml","html:target/Reports/invalid_lo.html"})
public class TestRunner {

}


