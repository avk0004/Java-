Feature: Amazon Add Product

  Background: 
    Given I was in amazon home page

  Scenario Outline: Invalid scenario
    Given I enter the login details <Mobile>
    Then I enter the password <Password>

    Examples: 
      | Mobile    | Password |
      | 321321321 | dummy    |
      | $^@       | dummy    |

  #Scenario validation for expected & unexpected product search result
  Scenario Outline: Search Products
    Given I search the <Product>
    Then I verify the page of <Product>

    Examples: 
      | Product            |
      | iPhone             |
      | macbook air laptop |

  Scenario Outline: Add Product to cart
    Given I search the <Product>
    Then I verify the page of <Product>
    Then I add the product to cart

    Examples: 
      | Product |
      | iPhone  |

  Scenario Outline: Buy Products
    Given I enter the login details <Mobile>
    Then I enter the password <Password>
    Then I search the <Product>
    Then I verify the page of <Product>
    Then I add the product to cart
    Then I proceed to checkout for <Product>

    Examples: 
      | Product | Mobile         | Password |
      | iPhone  | test@gmail.com | test     |
